$('.page-scroll').on('click',function(){
    
    var tujuan = $(this).attr('href');
    var elemenTujuan = $(tujuan);
    
    //$('body').scrollTop(elemenTujuan.offset().top);

    //e.preventDefault();
});